<?php

namespace RRCosmetics\Commands;

use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;

use RRCosmetics\Main;

class GadgetCommand extends PluginBase {

  private $plugin;
    
  public function __construct(Main $plugin) {
    $this->plugin = $plugin;
  }
    
  public function getPlugin() {
    return $this->plugin;
  }
  
  public function onCommand(CommandSender $sender, Command $cmd, $label, array $args) {
    switch($cmd->getName()) {
      case "par":
        if($sender->isOp()) {
          if(isset($args[0])) {
            $sender->sendMessage("§aUsage: §f/gadget <gadget name> §7OR §f/gadget list");
          }
        } else {
          $sender->sendMessage("§c§lX§r§c You do not have permission for this command");
        }
      break;
    }
  }
}